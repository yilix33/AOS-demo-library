sudo yum -y install java-1.8.0-openjdk
